/*
Section 002
ID U2310088
Hamroyev Mirshod
*/
#include "RealStateManagementSystem.h"
using namespace std;

int main(){
   // I made a class named "system" !
   Property system = Property(320,5,65038.453,"Urban House","apartment","Yunusubad region");
   system.calculatePropertyTax();
   Property system1 = Property(320,9,550385.75,"Zarafshan Houses","flat","Yakkasaray region");
   system1.calculatePropertyTax();
   return 0;
}
