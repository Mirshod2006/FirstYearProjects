#include <iostream>
#include <string>
using namespace std;
class Property{
   public:
   string propertyAddress = "";
     int propertyID = 0;
     string propertyName = "";
     string propertyType = "";
     double propertyValue = 0.0;
     int numberOfBedrooms = 0;
    Property(int propertyID,int numberOfBedrooms,double propertyValue,string propertyName, string propertyType,string propertyAddress)
    {
        this->numberOfBedrooms = numberOfBedrooms;
        this->propertyID = propertyID;
        this->propertyName = propertyName;
        this->propertyType = propertyType;
        this->propertyValue = propertyValue;
        this->propertyAddress = propertyAddress;
}
    void calculatePropertyTax(){
          cout <<"The tax for "<<propertyName<<" is "<< 0.1 * propertyValue<<" dollars!"<< endl;
    }

    ~Property();
};

Property::~Property(){
    cout << "Destructor called for "<<propertyName<< endl;
}
